Open the program
-------------------------
	- Run the Number Guessing Game.exe (Application file)


Navigating the menu
-------------------------
	1.) Follow the text printed in the program, and type user input within the program by using the keyboard
	2.) It will first ask you to give a number for the computer to guess
	3.) It will start and the computer will start guessing. You can tell if the computer is too low to high or its correct.
	4.) The program will keep running until the computer will find the correct number.
	5.) Press any key afterwards to close the program.

